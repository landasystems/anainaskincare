'use strict';


angular.module('app', [
    'ngAnimate',
    'ngSanitize',
    'ui.router',
    'ui.bootstrap',
    'oc.lazyLoad',
    'smart-table',
    'toaster',
    'ui.select',
    'angular-loading-bar',
    'highcharts-ng',
]);

