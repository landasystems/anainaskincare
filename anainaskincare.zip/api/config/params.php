<?php

return [
    'adminEmail' => 'admin@example.com',
    'pathImg' => '/var/www/anainaskincare/img/',
    'urlImg' => 'http://localhost/anainaskincare/img',
];
