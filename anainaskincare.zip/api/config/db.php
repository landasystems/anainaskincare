<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=landa_anaina',
    'username' => 'root',
    'password' => 'bismillah',
    //    'username' => 'landa_root',
//    'password' => 'landa12345*',
    'charset' => 'utf8',
];
