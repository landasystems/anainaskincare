<?php

echo $content;

?>